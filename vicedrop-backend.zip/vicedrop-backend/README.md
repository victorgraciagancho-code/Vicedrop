# ViceDrop — Backend real (Stripe + PayPal + pedidos)

## ✅ Ya está hecho (por Claude, en el código)
- API completa: crear sesión de pago Stripe, webhook, PayPal (crear/capturar), pedidos, productos.
- Base de datos lista (Prisma) con Users, Products, Categories, Variants, Suppliers, Orders, OrderItems, Payments, Shipments, Coupons, Customizations.
- CORS resuelto para que la tienda (otro dominio) pueda llamar a esta API.
- Checkout simplificado para no depender de sincronizar catálogo antes de tu primera venta.
- El checkout de la tienda ya tiene el campo para pegar esta URL y activar el pago real (Admin → Configuración).

## 🧑‍💻 Lo que solo puedes hacer tú (con tus cuentas/identidad)
1. **Crear cuenta de Stripe** → https://dashboard.stripe.com/register (pide verificación de identidad/negocio — no puedo hacerlo por ti).
2. **Sacar tus claves de Stripe** → Developers → API keys → copia `sk_test_...` y `pk_test_...` a tu `.env`.
3. **Crear cuenta de desarrollador de PayPal** (si quieres PayPal ya) → https://developer.paypal.com.
4. **Desplegar este proyecto** en Vercel (gratis): sube esta carpeta a GitHub → impórtalo en https://vercel.com/new → pega las variables de tu `.env`.
5. **Crear una base de datos Postgres** gratuita (Supabase o Neon) para producción y ponerla en `DATABASE_URL`.
6. **Registrar el webhook de Stripe** apuntando a tu backend ya desplegado (paso a paso más abajo).
7. **Pegar la URL de tu backend desplegado** en la tienda: Admin → Configuración → "Conectar el pago real".

Ninguno de estos 7 pasos los puedo ejecutar yo — necesitan tu identidad, tus cuentas o un despliegue real fuera de esta conversación. En cuanto los hagas, dime y reviso que todo encaje.

Este proyecto es el **backend** que falta para que la tienda ViceDrop pase de modo TEST a
cobros **reales**. La tienda visual (catálogo, carrito, checkout) vive publicada como
página en Claude; este backend es el que guarda tus claves secretas y habla de verdad
con Stripe y PayPal, algo que nunca debe hacerse desde una página que corre en el navegador.

## 1. Instalación local

```bash
npm install
cp .env.example .env
# Rellena .env con tus claves de Stripe/PayPal (puedes dejar las de TEST/sandbox al principio)
npx prisma migrate dev --name init
npm run dev
```

Esto levanta la API en `http://localhost:3000`.

## 2. Qué hace cada pieza

- **`prisma/schema.prisma`** — el modelo de datos completo: Users, Products, Categories,
  Variants, Suppliers, Orders, OrderItems, Payments, Shipments, Coupons, Customizations.
  Por defecto usa SQLite (cero configuración). Para producción, cambia el `provider` a
  `postgresql` y apunta `DATABASE_URL` a tu base de datos de Supabase/Neon/Railway.
- **`/api/checkout/stripe/create-session`** — recibe el carrito y los datos de envío,
  **recalcula los precios en el servidor** (nunca confía en lo que manda el navegador),
  crea el pedido en estado "Pendiente de pago" y devuelve la URL de Stripe Checkout.
- **`/api/checkout/stripe/webhook`** — Stripe llama a esta URL cuando el pago se confirma
  de verdad; es lo que marca el pedido como "Pagado". Tienes que registrar esta URL en tu
  dashboard de Stripe (ver paso 4).
- **`/api/checkout/paypal/create-order`** y **`capture-order`** — el equivalente para PayPal.
- **`/api/orders`** y **`/api/orders/[id]`** — listar pedidos y cambiar estado/tracking
  (protegidos con el token de `ADMIN_API_TOKEN`).
- **`/api/products`** — catálogo (lectura pública, escritura protegida).

## 3. Conectar la tienda visual a este backend

La tienda ya sabe hablar con este backend: en Admin → Configuración → "Conectar el pago real"
pega la URL donde despliegues esto (paso 4) y guarda. A partir de ahí, el botón de checkout
llama a `/api/checkout/stripe/create-session` y redirige de verdad a Stripe.

**Simplificación intencionada para tu primera venta:** este endpoint confía en el precio que
manda la tienda para cada línea, en vez de exigir que el producto ya exista en la base de datos
de este backend (evita tener que sincronizar catálogo antes de vender nada). Es razonable
mientras tú controlas ambos lados. Si más adelante quieres blindarlo contra manipulación de
precio en el navegador, sincroniza tu catálogo con `/api/products` y vuelve a activar la
validación server-side (está comentado en el código, en `create-session.js`).

**CORS:** la tienda y este backend viven en dominios distintos, así que las peticiones son
cross-origin. Ya está resuelto (`lib/cors.js`), pero para más seguridad pon `ALLOWED_ORIGIN`
en tu `.env` con la URL exacta de tu tienda publicada en vez de `*`.

## 4. Desplegar en Vercel (recomendado)

1. Sube esta carpeta a un repositorio de GitHub.
2. Impórtalo en [vercel.com](https://vercel.com/new).
3. En "Environment Variables", pega el contenido de tu `.env` (todas las claves de `.env.example`).
4. Para la base de datos en producción, crea un proyecto Postgres gratuito en
   [Supabase](https://supabase.com) o [Neon](https://neon.tech), pon esa URL en
   `DATABASE_URL`, y cambia `provider = "sqlite"` por `provider = "postgresql"` en
   `prisma/schema.prisma` antes de desplegar.
5. Tras el primer despliegue, ejecuta las migraciones contra la base de datos de
   producción: `npx prisma migrate deploy`.
6. En tu dashboard de Stripe → Developers → Webhooks, añade un endpoint apuntando a
   `https://tu-backend.vercel.app/api/checkout/stripe/webhook`, elige el evento
   `checkout.session.completed` (y `checkout.session.expired`), y copia el "Signing secret"
   a `STRIPE_WEBHOOK_SECRET`.

## 5. Pasar de TEST a LIVE

- Sustituye `sk_test_...` / `pk_test_...` por tus claves `sk_live_...` / `pk_live_...` de Stripe.
- Cambia `PAYPAL_ENV=sandbox` a `PAYPAL_ENV=live` y usa las credenciales de tu app "Live" de PayPal.
- Vuelve a registrar el webhook de Stripe apuntando a las claves Live (Stripe tiene webhooks
  separados para test y live).

## 6. Seguridad

- El `.env` real nunca debe subirse a git (ya está en `.gitignore`).
- `ADMIN_API_TOKEN` es una protección mínima para endpoints de administración; para un
  panel de verdad con varios usuarios, sustitúyelo por NextAuth o similar.
- Los precios y el estado "activo"/"demo" de cada producto se comprueban siempre en el
  servidor antes de cobrar, para que nadie pueda manipular el precio desde el navegador.
