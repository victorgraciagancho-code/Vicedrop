export default function Home() {
  return (
    <main style={{ fontFamily: 'sans-serif', padding: 40, maxWidth: 640, margin: '0 auto' }}>
      <h1>ViceDrop — Backend API</h1>
      <p>
        Este proyecto expone la API real (Stripe, PayPal, productos y pedidos) que consume
        la tienda ViceDrop. No es la tienda visual — esa vive en el artifact publicado en Claude.
      </p>
      <p>Endpoints principales:</p>
      <ul>
        <li><code>GET /api/products</code></li>
        <li><code>POST /api/checkout/stripe/create-session</code></li>
        <li><code>POST /api/checkout/stripe/webhook</code> (Stripe lo llama, no lo llames tú)</li>
        <li><code>POST /api/checkout/paypal/create-order</code></li>
        <li><code>POST /api/checkout/paypal/capture-order</code></li>
        <li><code>GET /api/orders</code> (requiere cabecera <code>x-admin-token</code>)</li>
      </ul>
      <p>Consulta el README.md del proyecto para desplegarlo y conectarlo a la tienda.</p>
    </main>
  );
}
