const prisma = require('../../../lib/prisma');
const { requireAdmin } = require('../../../lib/adminAuth');

module.exports = async function handler(req, res) {
  if (req.method === 'GET') {
    const suppliers = await prisma.supplier.findMany({ include: { products: true } });
    return res.status(200).json(suppliers);
  }

  if (req.method === 'POST') {
    if (!requireAdmin(req, res)) return;
    const { name, url, apiConfigured } = req.body;
    const supplier = await prisma.supplier.create({ data: { name, url, apiConfigured: !!apiConfigured } });
    return res.status(201).json(supplier);
  }

  res.setHeader('Allow', ['GET', 'POST']);
  return res.status(405).end(`Method ${req.method} Not Allowed`);
};
