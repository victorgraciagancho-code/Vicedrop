const prisma = require('../../../../lib/prisma');
const { client, sdk } = require('../../../../lib/paypal');
const { withCors } = require('../../../../lib/cors');

module.exports = async function handler(req, res) {
  if (withCors(req, res)) return;
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).end('Method Not Allowed');
  }

  try {
    const { customer, items } = req.body;
    if (!customer?.email || !items?.length) {
      return res.status(400).json({ error: 'Faltan datos del cliente o del carrito.' });
    }

    const productIds = items.map((i) => i.productId);
    const products = await prisma.product.findMany({ where: { id: { in: productIds } } });
    const productMap = Object.fromEntries(products.map((p) => [p.id, p]));

    let subtotal = 0;
    const orderItemsData = [];
    for (const item of items) {
      const product = productMap[item.productId];
      if (!product || !product.active) return res.status(400).json({ error: `Producto no disponible: ${item.productId}` });
      if (product.type === 'demo') return res.status(400).json({ error: `"${product.name}" es DEMO y no se puede comprar.` });
      const qty = item.quantity || 1;
      subtotal += product.precioVenta * qty;
      orderItemsData.push({
        productId: product.id,
        variantLabel: item.variantLabel || null,
        quantity: qty,
        unitPrice: product.precioVenta,
        customization: item.personalization ? { create: { text: item.personalization } } : undefined,
      });
    }
    const shippingCost = 4.5;
    const total = +(subtotal + shippingCost).toFixed(2);
    const tax = +((subtotal * 0.21) / 1.21).toFixed(2);

    const orderNumber = 'VD-' + Date.now().toString().slice(-8);
    const dbOrder = await prisma.order.create({
      data: {
        orderNumber,
        status: 'Pendiente de pago',
        customerName: `${customer.nombre} ${customer.apellidos}`.trim(),
        customerEmail: customer.email,
        customerPhone: customer.telefono || null,
        shippingAddr: customer.direccion,
        shippingCP: customer.cp,
        shippingCity: customer.ciudad,
        shippingProv: customer.provincia || null,
        shippingCountry: customer.pais || 'España',
        subtotal: +subtotal.toFixed(2),
        shippingCost,
        tax,
        total,
        paymentMethod: 'paypal',
        items: { create: orderItemsData },
      },
    });

    const request = new sdk.orders.OrdersCreateRequest();
    request.prefer('return=representation');
    request.requestBody({
      intent: 'CAPTURE',
      purchase_units: [{
        reference_id: dbOrder.id,
        amount: { currency_code: 'EUR', value: total.toFixed(2) },
      }],
    });

    const ppResponse = await client().execute(request);

    await prisma.payment.create({
      data: {
        orderId: dbOrder.id,
        provider: 'paypal',
        providerRef: ppResponse.result.id,
        status: 'pending',
        amount: total,
      },
    });

    return res.status(200).json({ paypalOrderId: ppResponse.result.id, orderNumber: dbOrder.orderNumber });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'No se pudo crear la orden de PayPal.', detail: err.message });
  }
};
