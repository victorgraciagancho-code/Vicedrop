const prisma = require('../../../../lib/prisma');
const { client, sdk } = require('../../../../lib/paypal');
const { withCors } = require('../../../../lib/cors');

module.exports = async function handler(req, res) {
  if (withCors(req, res)) return;
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).end('Method Not Allowed');
  }

  try {
    const { paypalOrderId } = req.body;
    if (!paypalOrderId) return res.status(400).json({ error: 'Falta paypalOrderId' });

    const request = new sdk.orders.OrdersCaptureRequest(paypalOrderId);
    request.requestBody({});
    const capture = await client().execute(request);

    const payment = await prisma.payment.findFirst({ where: { providerRef: paypalOrderId } });
    if (payment) {
      await prisma.payment.update({ where: { id: payment.id }, data: { status: 'paid' } });
      await prisma.order.update({ where: { id: payment.orderId }, data: { status: 'Pagado' } });
    }

    return res.status(200).json({ status: capture.result.status });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'No se pudo capturar el pago de PayPal.', detail: err.message });
  }
};
