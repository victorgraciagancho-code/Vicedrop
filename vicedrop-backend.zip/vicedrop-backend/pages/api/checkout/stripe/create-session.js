const prisma = require('../../../../lib/prisma');
const stripe = require('../../../../lib/stripe');
const { withCors } = require('../../../../lib/cors');

// Body esperado:
// {
//   customer: { nombre, apellidos, email, telefono, direccion, cp, ciudad, provincia, pais },
//   items: [{ productId, name, variantLabel, quantity, unitPrice, personalization }]
// }
//
// NOTA IMPORTANTE (léela antes de recibir tu primera venta real):
// Para poder funcionar desde el primer día SIN tener que sincronizar antes tu catálogo
// completo en esta base de datos, este endpoint confía en el precio (unitPrice) que manda
// la tienda para cada línea, en vez de recalcularlo contra una tabla Product ya existente.
// Esto es razonable mientras tú mismo controlas el catálogo y los precios que se muestran
// en la tienda (nadie más lo edita). Si más adelante abres la tienda a que terceros
// gestionen productos, o quieres blindarte contra manipulación del precio en el navegador,
// vuelve a activar la validación: sincroniza tus productos en la tabla Product (puedes usar
// /api/products con tu ADMIN_API_TOKEN) y descomenta el bloque "recalcular contra la BD" más abajo.
module.exports = async function handler(req, res) {
  if (withCors(req, res)) return;
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).end('Method Not Allowed');
  }

  try {
    const { customer, items } = req.body;
    if (!customer?.email || !items?.length) {
      return res.status(400).json({ error: 'Faltan datos del cliente o del carrito.' });
    }

    let subtotal = 0;
    const orderItemsData = [];
    const stripeLineItems = [];

    for (const item of items) {
      const unitPrice = Number(item.unitPrice);
      const qty = Number(item.quantity) || 1;
      if (!item.name || !unitPrice || unitPrice <= 0) {
        return res.status(400).json({ error: `Línea de pedido inválida: ${JSON.stringify(item)}` });
      }
      subtotal += unitPrice * qty;
      orderItemsData.push({
        productId: item.productId || undefined,
        productName: item.name,
        variantLabel: item.variantLabel || null,
        quantity: qty,
        unitPrice,
        customization: item.personalization ? { create: { text: item.personalization } } : undefined,
      });
      stripeLineItems.push({
        price_data: {
          currency: 'eur',
          product_data: { name: item.name + (item.variantLabel ? ` (${item.variantLabel})` : '') },
          unit_amount: Math.round(unitPrice * 100),
        },
        quantity: qty,
      });
    }

    const shippingCost = Number(req.body.shippingCost) || 4.5; // debe coincidir con lo mostrado en la tienda
    const total = +(subtotal + shippingCost).toFixed(2);
    const tax = +((subtotal * 0.21) / 1.21).toFixed(2); // IVA incluido en el precio

    // Crear el pedido en estado "Pendiente de pago" ANTES de redirigir a Stripe
    const orderNumber = 'VD-' + Date.now().toString().slice(-8);
    const order = await prisma.order.create({
      data: {
        orderNumber,
        status: 'Pendiente de pago',
        customerName: `${customer.nombre} ${customer.apellidos}`.trim(),
        customerEmail: customer.email,
        customerPhone: customer.telefono || null,
        shippingAddr: customer.direccion,
        shippingCP: customer.cp,
        shippingCity: customer.ciudad,
        shippingProv: customer.provincia || null,
        shippingCountry: customer.pais || 'España',
        subtotal: +subtotal.toFixed(2),
        shippingCost,
        tax,
        total,
        paymentMethod: 'stripe',
        items: { create: orderItemsData },
      },
    });

    stripeLineItems.push({
      price_data: { currency: 'eur', product_data: { name: 'Envío' }, unit_amount: Math.round(shippingCost * 100) },
      quantity: 1,
    });

    // Tras pagar, Stripe debe devolver al cliente a la TIENDA (el artifact publicado),
    // no a este backend (que no tiene páginas de cliente). Configura STOREFRONT_URL en .env
    // con el enlace del artifact publicado de tu tienda.
    const storefrontUrl = process.env.STOREFRONT_URL || process.env.PUBLIC_URL;
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      customer_email: customer.email,
      line_items: stripeLineItems,
      success_url: `${storefrontUrl}?pedido=${order.orderNumber}&pago=ok`,
      cancel_url: `${storefrontUrl}?pedido=${order.orderNumber}&pago=cancelado`,
      metadata: { orderId: order.id, orderNumber: order.orderNumber },
    });

    await prisma.payment.create({
      data: {
        orderId: order.id,
        provider: 'stripe',
        providerRef: session.id,
        status: 'pending',
        amount: total,
      },
    });

    return res.status(200).json({ url: session.url, orderNumber: order.orderNumber });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'No se pudo crear la sesión de pago.', detail: err.message });
  }
};
