const prisma = require('../../../lib/prisma');
const { requireAdmin } = require('../../../lib/adminAuth');

module.exports = async function handler(req, res) {
  if (req.method === 'GET') {
    if (!requireAdmin(req, res)) return;
    const orders = await prisma.order.findMany({
      include: { items: { include: { product: true, customization: true } }, payment: true, shipment: true },
      orderBy: { createdAt: 'desc' },
    });
    return res.status(200).json(orders);
  }

  res.setHeader('Allow', ['GET']);
  return res.status(405).end(`Method ${req.method} Not Allowed`);
};
