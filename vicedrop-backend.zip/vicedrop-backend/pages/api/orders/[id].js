const prisma = require('../../../lib/prisma');
const { requireAdmin } = require('../../../lib/adminAuth');

const VALID_STATUSES = [
  'Pendiente de pago', 'Pagado', 'Preparando', 'Pedido al proveedor',
  'Enviado', 'En tránsito', 'Entregado', 'Cancelado', 'Reembolsado',
];

module.exports = async function handler(req, res) {
  const { id } = req.query;

  if (req.method === 'GET') {
    const order = await prisma.order.findUnique({
      where: { id },
      include: { items: { include: { product: true, customization: true } }, payment: true, shipment: true },
    });
    if (!order) return res.status(404).json({ error: 'Pedido no encontrado' });
    return res.status(200).json(order);
  }

  if (req.method === 'PATCH') {
    if (!requireAdmin(req, res)) return;
    const { status, trackingCode, carrier } = req.body;
    if (status && !VALID_STATUSES.includes(status)) {
      return res.status(400).json({ error: `Estado inválido. Usa uno de: ${VALID_STATUSES.join(', ')}` });
    }
    const data = {};
    if (status) data.status = status;
    const order = await prisma.order.update({ where: { id }, data });

    if (trackingCode || carrier) {
      await prisma.shipment.upsert({
        where: { orderId: id },
        update: { trackingCode, carrier },
        create: { orderId: id, trackingCode, carrier, status: 'Enviado' },
      });
    }
    return res.status(200).json(order);
  }

  res.setHeader('Allow', ['GET', 'PATCH']);
  return res.status(405).end(`Method ${req.method} Not Allowed`);
};
