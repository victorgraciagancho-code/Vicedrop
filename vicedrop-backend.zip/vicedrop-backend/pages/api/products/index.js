const prisma = require('../../../lib/prisma');
const { requireAdmin } = require('../../../lib/adminAuth');
const { withCors } = require('../../../lib/cors');

module.exports = async function handler(req, res) {
  if (withCors(req, res)) return;
  if (req.method === 'GET') {
    const { category, type, active } = req.query;
    const where = {};
    if (category) where.category = { slug: category };
    if (type) where.type = type;
    if (active !== undefined) where.active = active === 'true';
    const products = await prisma.product.findMany({
      where,
      include: { category: true, supplier: true, variants: true },
      orderBy: { createdAt: 'desc' },
    });
    return res.status(200).json(products);
  }

  if (req.method === 'POST') {
    if (!requireAdmin(req, res)) return;
    const b = req.body;
    const product = await prisma.product.create({
      data: {
        name: b.name,
        description: b.description || '',
        type: b.type || 'demo',
        active: b.active !== undefined ? b.active : true,
        personalizable: !!b.personalizable,
        costProveedor: b.costProveedor || 0,
        costEnvio: b.costEnvio || 0,
        precioVenta: b.precioVenta,
        categoryId: b.categoryId,
        supplierId: b.supplierId || null,
        variants: b.variants
          ? { create: b.variants.map((v) => ({ size: v.size, color: v.color, stock: v.stock ?? 999 })) }
          : undefined,
      },
      include: { variants: true },
    });
    return res.status(201).json(product);
  }

  res.setHeader('Allow', ['GET', 'POST']);
  return res.status(405).end(`Method ${req.method} Not Allowed`);
};
