const prisma = require('../../../lib/prisma');
const { requireAdmin } = require('../../../lib/adminAuth');

module.exports = async function handler(req, res) {
  const { id } = req.query;

  if (req.method === 'GET') {
    const product = await prisma.product.findUnique({
      where: { id },
      include: { category: true, supplier: true, variants: true },
    });
    if (!product) return res.status(404).json({ error: 'Producto no encontrado' });
    return res.status(200).json(product);
  }

  if (req.method === 'PATCH') {
    if (!requireAdmin(req, res)) return;
    const b = req.body;
    const data = {};
    ['name', 'description', 'type', 'active', 'personalizable', 'costProveedor', 'costEnvio', 'precioVenta', 'categoryId', 'supplierId']
      .forEach((k) => { if (b[k] !== undefined) data[k] = b[k]; });
    const product = await prisma.product.update({ where: { id }, data });
    return res.status(200).json(product);
  }

  if (req.method === 'DELETE') {
    if (!requireAdmin(req, res)) return;
    await prisma.product.delete({ where: { id } });
    return res.status(204).end();
  }

  res.setHeader('Allow', ['GET', 'PATCH', 'DELETE']);
  return res.status(405).end(`Method ${req.method} Not Allowed`);
};
